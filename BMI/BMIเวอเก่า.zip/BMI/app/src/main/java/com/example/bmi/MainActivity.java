package com.example.bmi;

import android.graphics.Color;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        final TextView output_bmi = findViewById(R.id.TextView_bmi);
        final TextView output_wc = findViewById(R.id.TextView_wc);
        final EditText input_h = findViewById(R.id.editText_h);
        final EditText input_w = findViewById(R.id.editText_w);
        final Button calculate = findViewById(R.id.button_calculate);

        // ตั้งค่าฟิลเตอร์สำหรับ EditText เพื่อจำกัดการรับค่าตัวเลข
        input_h.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(8, 2)});
        input_w.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(8, 2)});

        // กำหนด DecimalFormat สำหรับการจัดรูปแบบตัวเลข
        DecimalFormat formatter = new DecimalFormat("#,###.##");

        // ตั้งค่าให้ปุ่มคำนวณทำงานเมื่อคลิก
        calculate.setOnClickListener(v -> calculateBMI(input_h, input_w, output_bmi, output_wc));
    }

    // ฟังก์ชันสำหรับคำนวณ BMI
    private void calculateBMI(EditText input_h, EditText input_w, TextView output_bmi, TextView output_wc) {
        String hStr = input_h.getText().toString();
        String wStr = input_w.getText().toString();

        // ตรวจสอบว่าผู้ใช้กรอกข้อมูลครบหรือไม่
        if (!hStr.isEmpty() && !wStr.isEmpty()) {
            try {
                double h = Double.parseDouble(hStr) / 100; // แปลงส่วนสูงเป็นเมตร
                double w = Double.parseDouble(wStr);

                // คำนวณ BMI
                double bmi = w / (h * h);

                // จัดรูปแบบการแสดงผลของ BMI
                DecimalFormat formatter = new DecimalFormat("#,###.##");
                String bmiResult = formatter.format(bmi);
                output_bmi.setText(bmiResult);

                // ตรวจสอบและแสดงผลตามเกณฑ์ BMI
                if (bmi < 16) {
                    output_wc.setText(R.string.severe_thinness);
                    output_wc.setBackgroundColor(Color.RED);
                } else if (bmi >= 16 && bmi < 17) {
                    output_wc.setText(R.string.moderate_thinness);
                    output_wc.setBackgroundColor(Color.parseColor("#FFA500"));
                } else if (bmi >= 17 && bmi < 18.5) {
                    output_wc.setText(R.string.mild_thinness);
                    output_wc.setBackgroundColor(Color.YELLOW);
                } else if (bmi >= 18.5 && bmi < 25) {
                    output_wc.setText(R.string.normal);
                    output_wc.setBackgroundColor(Color.parseColor("#AEF359"));
                } else if (bmi >= 25 && bmi < 30) {
                    output_wc.setText(R.string.overweight);
                    output_wc.setBackgroundColor(Color.YELLOW);
                } else if (bmi >= 30 && bmi < 35) {
                    output_wc.setText(R.string.obese_i);
                    output_wc.setBackgroundColor(Color.parseColor("#FFA500"));
                } else if (bmi >= 35 && bmi < 40) {
                    output_wc.setText(R.string.obese_ii);
                    output_wc.setBackgroundColor(Color.RED);
                } else if (bmi >= 40) {
                    output_wc.setText(R.string.obese_iii);
                    output_wc.setBackgroundColor(Color.parseColor("#930000"));
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, R.string.input_error, Toast.LENGTH_SHORT).show();
            }
        } else {
            // แสดงข้อความเตือนให้กรอกข้อมูลให้ครบ
            Toast.makeText(this, R.string.input_complete, Toast.LENGTH_SHORT).show();
        }
    }

    // ฟิลเตอร์สำหรับการจำกัดจำนวนตัวเลขใน EditText
    static class DecimalDigitsInputFilter implements InputFilter {
        private final Pattern mPattern;

        DecimalDigitsInputFilter(int digits, int digitsAfterZero) {
            mPattern = Pattern.compile("[0-9]{0," + (digits - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?");
        }

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            Matcher matcher = mPattern.matcher(dest);
            if (!matcher.matches())
                return ""; // หากไม่ตรงตามรูปแบบให้ไม่อนุญาตให้กรอก
            return null; // อนุญาตให้กรอก
        }
    }







}